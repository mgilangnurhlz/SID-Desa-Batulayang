import express from "express";
import cors from "cors";
import session from "express-session";
import db from "./config/Database.js";
import SequelizeStore from "connect-session-sequelize";
import FileUpload from "express-fileupload";

//Routes
import UserRoute from "./routes/UserRoute.js";
import UmkmRoute from "./routes/UmkmRoute.js";
import AuthRoute from "./routes/AuthRoute.js";
import BeritaRoute from "./routes/BeritaRoute.js";
import WisataRoute from "./routes/WisataRoute.js";

const app = express();

const sessionStore = SequelizeStore(session.Store);

const store = new sessionStore({
  db: db,
});

(async () => {
  await db.sync();
})();

app.use(
  session({
    secret: "13u4tnkdfsi8348ijjnsduauenauasdasdas",
    resave: false,
    saveUninitialized: true,
    store: store,
    cookie: {
      secure: "auto",
    },
  })
);

app.use(
  cors({
    credentials: true,
    origin: "http://localhost:3000",
  })
);

app.use(express.json());
app.use(FileUpload());
app.use(express.static("public"));
app.use(UserRoute);
app.use(AuthRoute);
app.use(UmkmRoute);
app.use(WisataRoute);
app.use(BeritaRoute);

store.sync();
app.get("/", (req, res) => {
  res.send("Gilang dan Silpiy!");
});
app.listen(5002, () => {
  console.log("Server up and running...");
});
