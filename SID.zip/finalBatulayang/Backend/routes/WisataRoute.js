import express from "express";
import {
  getWisatas,
  getWisataById,
  saveWisata,
  updateWisata,
  deleteWisata,
} from "../controllers/Wisata.js";
import { verifyUser, adminOnly } from "../middleware/AuthUser.js";

const router = express.Router();

router.get("/wisatas", getWisatas);
router.get("/wisatas/:id", getWisataById);
router.post("/wisatas", adminOnly, saveWisata);
router.patch("/wisatas/:id", adminOnly, updateWisata);
router.delete("/wisatas/:id", adminOnly, deleteWisata);

export default router;
