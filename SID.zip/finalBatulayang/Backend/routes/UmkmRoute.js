import express from "express";
import {
  getUmkms,
  getUmkmById,
  saveUmkm,
  updateUmkm,
  deleteUmkm,
} from "../controllers/Umkm.js";
import { verifyUser, adminOnly } from "../middleware/AuthUser.js";

const router = express.Router();

router.get("/umkms", getUmkms);
router.get("/umkms/:id", getUmkmById);
router.post("/umkms", adminOnly, saveUmkm);
router.patch("/umkms/:id", adminOnly, updateUmkm);
router.delete("/umkms/:id", adminOnly, deleteUmkm);

export default router;
