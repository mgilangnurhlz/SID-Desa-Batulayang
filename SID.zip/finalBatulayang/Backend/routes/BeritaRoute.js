import express from "express";
import {
  getBeritas,
  getBeritaById,
  saveBerita,
  updateBerita,
  deleteBerita,
} from "../controllers/Berita.js";
import { verifyUser, adminOnly } from "../middleware/AuthUser.js";

const router = express.Router();

router.get("/beritas", getBeritas);
router.get("/beritas/:id", getBeritaById);
router.post("/beritas", adminOnly, saveBerita);
router.patch("/beritas/:id", adminOnly, updateBerita);
router.delete("/beritas/:id", adminOnly, deleteBerita);

export default router;
