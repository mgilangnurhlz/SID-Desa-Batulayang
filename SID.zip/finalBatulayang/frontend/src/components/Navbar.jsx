import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import logo from "../logo.png";
import { useDispatch, useSelector } from "react-redux";
import { LogOut, reset } from "../features/authSlice";
import "../static/css/navbaradmin.css";
const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);

  const logout = () => {
    dispatch(LogOut());
    dispatch(reset());
    navigate("/");
  };

  return (
    <div>
      <nav
        className="navbar is-fixed-top has-shadow"
        role="navigation"
        aria-label="main navigation"
      >
        <div className="navbar-brand">
          <NavLink to="/dashboard" className="navbar-item">
            <img src={logo} width="112" height="28" alt="logo" />
          </NavLink>
        </div>

        <div className="navbar-menu" id="navbarBasicExample">
          <div className="navbar-end">
            <div className="navbar-item">
              <div className="buttons">
                <NavLink to="/dashboard" className="navbar-item">
                  Dashboard
                </NavLink>
                <NavLink to="/umkms" className="navbar-item">
                  UMKM
                </NavLink>
                <NavLink to="/wisatas" className="navbar-item">
                  Wisata
                </NavLink>
                <NavLink to="/beritas" className="navbar-item">
                  Berita
                </NavLink>
                <NavLink to="/users" className="navbar-item">
                  User
                </NavLink>
                <button onClick={logout} className="button is-light">
                  Log out
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
