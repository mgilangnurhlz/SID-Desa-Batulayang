import React from "react";
import "../static/css/footer.css";

const Footer = () => {
  return (
    <footer className="footeri">
      <div className="footeri-content">
        <p>Developed by KKN SISDAMAS UIN Bandung, Kelompok 208 & 210</p>
      </div>
    </footer>
  );
};

export default Footer;
