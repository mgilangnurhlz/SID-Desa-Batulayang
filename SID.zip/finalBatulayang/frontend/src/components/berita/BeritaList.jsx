import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const BeritaList = () => {
  const [beritas, setBerita] = useState([]);

  useEffect(() => {
    getBerita();
  }, []);

  const getBerita = async () => {
    const response = await axios.get("http://localhost:5002/beritas");
    setBerita(response.data);
  };

  const deleteBerita = async (beritaId) => {
    try {
      await axios.delete(`http://localhost:5002/beritas/${beritaId}`);
      getBerita();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="container mt-5">
      <Link to="/beritas/add" className="button is-success">
        Add New
      </Link>
      <div className="columns is-multiline mt-2">
        {beritas.map((berita) => (
          <div className="column is-one-quarter" key={berita.id}>
            <div className="card">
              <div className="card-image">
                <figure className="image is-4by3">
                  <img src={berita.url} alt="something" />
                </figure>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{berita.name}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{berita.desc1}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{berita.desc2}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{berita.penulis}</p>
                  </div>
                </div>
              </div>

              <footer className="card-footer">
                <Link to={`edit/${berita.id}`} className="card-footer-item">
                  Edit
                </Link>
                <button
                  onClick={() => deleteBerita(berita.id)}
                  className="card-footer-item"
                >
                  Delete
                </button>
              </footer>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BeritaList;
