import React from "react";
import { Link } from "react-router-dom";
import "../../static/css/navbar.css";
import { FaInstagram, FaYoutube } from "react-icons/fa";

function App() {
  return (
    <div className="App">
      <nav>
        <div className="nav-logo">Batulayang</div>
        <div className="nav-toggle">
          <span></span>
          <span></span>
          <span></span>
        </div>
        <div className="nav-links active">
          <ul className="nav-list">
            <li>
              <Link to={`/`} className="card-footer-item">
                Beranda
              </Link>
            </li>
            <li>
              <Link to={`/beritakami`} className="card-footer-item">
                Berita
              </Link>
            </li>
            <li>
              <Link to={`/wisatakami`} className="card-footer-item">
                Wisata
              </Link>
            </li>
            <li>
              <Link to={`/umkmkami`} className="card-footer-item">
                Umkm
              </Link>
            </li>
          </ul>
        </div>
        <div className="kanan">
          <div className="satu">
            <a href="https://www.instagram.com/desa.batulayang/">
              <FaInstagram />
            </a>

            <a href="https://www.youtube.com/@desabatulayang9561">
              <FaYoutube />
            </a>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default App;
