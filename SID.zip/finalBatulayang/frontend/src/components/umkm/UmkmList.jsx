import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const UmkmList = () => {
  const [umkms, setUmkm] = useState([]);

  useEffect(() => {
    getUmkm();
  }, []);

  const getUmkm = async () => {
    const response = await axios.get("http://localhost:5002/umkms");
    setUmkm(response.data);
  };

  const deleteUmkm = async (umkmId) => {
    try {
      await axios.delete(`http://localhost:5002/umkms/${umkmId}`);
      getUmkm();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="container mt-5">
      <Link to="/umkms/add" className="button is-success">
        Add New
      </Link>
      <div className="columns is-multiline mt-2">
        {umkms.map((umkm) => (
          <div className="column is-one-quarter" key={umkm.id}>
            <div className="card">
              <div className="card-image">
                <figure className="image is-4by3">
                  <img src={umkm.url} alt="something" />
                </figure>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{umkm.name}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{umkm.desc1}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{umkm.desc2}</p>
                  </div>
                </div>
              </div>
              <div className="card-content">
                <div className="media">
                  <div className="media-content">
                    <p className="title is-4">{umkm.nowa}</p>
                  </div>
                </div>
              </div>

              <footer className="card-footer">
                <Link to={`edit/${umkm.id}`} className="card-footer-item">
                  Edit
                </Link>
                <button
                  onClick={() => deleteUmkm(umkm.id)}
                  className="card-footer-item"
                >
                  Delete
                </button>
              </footer>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UmkmList;
