import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Navbar from "../components/navbar/NavbarUser";

import Coba2 from "../static/images/IMG.png";
import Video from "../static/images/vidbatulayang.mp4";
import "../static/css/index.css";

import Footer from "../components/Footeri";

const Index = () => {
  const [beritas, setBerita] = useState([]);
  const [wisatas, setWisata] = useState([]);
  const [umkms, setUmkm] = useState([]);
  useEffect(() => {
    getBerita();
    getWisata();
    getUmkm();
  }, []);

  const getBerita = async () => {
    const response = await axios.get("http://localhost:5002/beritas");
    const totalBeritas = response.data.length;
    const latestBeritas = response.data
      .slice(totalBeritas - 6, totalBeritas)
      .reverse();

    setBerita(latestBeritas);
  };

  const getWisata = async () => {
    const response = await axios.get("http://localhost:5002/wisatas");
    const totalWisatas = response.data.length;
    const latestWisatas = response.data.slice(totalWisatas - 3, totalWisatas);
    setWisata(latestWisatas);
  };
  const getUmkm = async () => {
    const response = await axios.get("http://localhost:5002/umkms");
    const totalUmkms = response.data.length;
    const latestUmkms = response.data.slice(totalUmkms - 6, totalUmkms);
    setUmkm(latestUmkms);
  };

  return (
    <div className="body">
      <Navbar />

      <div className="fullscreen-video-container">
        <video className="fullscreen-video" autoPlay loop muted>
          <source src={Video} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div className="caption">
          <h1>Selamat Datang di Desa Batulayang</h1>
          <h2>"Agamis Demokrasi Unggul Maju dan Harmonis"</h2>
        </div>
      </div>

      <div className="image-and-text-container">
        <div className="image-container">
          <img src={Coba2} alt="Gambar" className="image" />
        </div>
        <div className="text">
          <h1>
            "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aperiam
            recusandae in nemo sequi fuga voluptas quam est eaque molestias
            illum impedit nulla fugit consequatur omnis praesentium ab, iusto
            modi vero!""
          </h1>
        </div>
      </div>

      <div className="map">
        <h1>Temukan Kami</h1>
        <div className="google-map-container">
          <iframe
            className="google-map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31683.096056086568!2d107.42845483138669!3d-6.963590455052374!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68f045c37c93ab%3A0x18cbf4e0ddab5bdb!2sBatulayang%2C%20Kec.%20Cililin%2C%20Kabupaten%20Bandung%20Barat%2C%20Jawa%20Barat!5e0!3m2!1sid!2sid!4v1691728329025!5m2!1sid!2sid"
            allowFullScreen=""
            loading="lazy"
            title="Google Maps"
          ></iframe>
        </div>
      </div>

      <div className="juduls">
        <h1>UMKM Unggulan</h1>
      </div>

      <section className="articles">
        {umkms.map((umkm) => (
          <article key={umkm.id}>
            <div className="article-wrapper">
              <figure>
                <img src={umkm.url} alt="" />
              </figure>
              <div className="article-body">
                <h2>{umkm.name}</h2>
                <p>{umkm.desc1}</p>
                <Link to={`/umkmkami/${umkm.id}`}>
                  <a className="read-more">
                    Baca selengkapnya{" "}
                    <span className="sr-only">about this is some title</span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="icon"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </a>
                </Link>
              </div>
            </div>
          </article>
        ))}
      </section>
      <div className="banner">
        <div className="juduls">
          <h1>Informasi Lokasi</h1>
        </div>
        <div className="info">
          <div className="info-item">
            <strong>Negara:</strong>
            <span>Indonesia</span>
          </div>
          <div className="info-item">
            <strong>Provinsi:</strong>
            <span>Jawa Barat</span>
          </div>
          <div className="info-item">
            <strong>Kabupaten:</strong>
            <span>Bandung Barat</span>
          </div>
          <div className="info-item">
            <strong>Kecamatan:</strong>
            <span>Cililin</span>
          </div>
          <div className="info-item">
            <strong>Kodepos:</strong>
            <span>40567</span>
          </div>
          <div className="info-item">
            <strong>Kode Kemendagri:</strong>
            <span>32.17.11.2003 </span>
          </div>
          <div className="info-item">
            <strong>Luas:</strong>
            <span>9,67 km²</span>
          </div>
          <div className="info-item">
            <strong>Jumlah penduduk:</strong>
            <span>10.806 jiwa</span>
          </div>
          <div className="info-item">
            <strong>Kepadatan:</strong>
            <span>1.118 jiwa/km²</span>
          </div>
        </div>
      </div>

      <div className="juduls">
        <h1>Wisata Pilihan</h1>
      </div>

      <main>
        {wisatas.map((wisata) => (
          <div className="cardo" key={wisata.id}>
            <img src={wisata.url} alt="" />
            <div className="cardo-content">
              <h2>{wisata.name}</h2>
              <p>{wisata.desc1}</p>

              <a href={`/wisatakami/${wisata.id}`} className="butto">
                Baca selengkapnya →
              </a>
            </div>
          </div>
        ))}
      </main>

      <div className="bodyyy">
        <div className="main">
          <div className="juduls">
            <h1>Berita Terbaru</h1>
          </div>
          <ul className="cards">
            {beritas.map((berita) => (
              <li className="cards_item" key={berita.id}>
                <div className="card">
                  <div className="card_image">
                    <img src={berita.url} alt="" />
                  </div>
                  <div className="card_content">
                    <h2 className="card_title">{berita.name}</h2>
                    <p className="card_text">{berita.desc1}</p>
                    <Link to={`/beritakami/${berita.id}`}>
                      <div className="btn card_btn">Baca Selengkapnya</div>
                    </Link>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Index;
