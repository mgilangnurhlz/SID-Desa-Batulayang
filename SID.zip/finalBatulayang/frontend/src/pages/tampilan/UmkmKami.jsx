import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Navbar from "../../components/navbar/NavbarUser";
import Footer from "../../components/Footeri";
const UmkmKu = () => {
  const [umkms, setUmkm] = useState([]);
  useEffect(() => {
    getUmkm();
  }, []);

  const getUmkm = async () => {
    const response = await axios.get("http://localhost:5002/umkms");
    setUmkm(response.data);
  };

  return (
    <div className="">
      <Navbar />
      <div className="kebawah">
        {umkms.map((umkm) => (
          <div className="blog-post" key={umkm.id}>
            <div className="blog-post__img">
              <img src={umkm.url} alt="something" />
            </div>
            <div className="blog-post__info">
              <h1 className="blog-post__title">{umkm.name}</h1>
              <p className="blog-post__text">{umkm.desc1}</p>
              <Link to={`/umkmkami/${umkm.id}`}>
                <a className="blog-post__cta">Baca Selengkapnya</a>
              </Link>
            </div>
          </div>
        ))}
      </div>
      <Footer />
    </div>
  );
};
export default UmkmKu;
