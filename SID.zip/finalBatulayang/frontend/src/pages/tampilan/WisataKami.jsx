import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Navbar from "../../components/navbar/NavbarUser";
import Footer from "../../components/Footeri";
const WisataKu = () => {
  const [wisatas, setWisata] = useState([]);

  useEffect(() => {
    getWisata();
  }, []);

  const getWisata = async () => {
    const response = await axios.get("http://localhost:5002/wisatas");
    setWisata(response.data);
  };

  return (
    <div className="">
      <Navbar />
      <div className="kebawah">
        {wisatas.map((wisata) => (
          <div className="blog-post" key={wisata.id}>
            <div className="blog-post__img">
              <img src={wisata.url} alt="something" />
            </div>
            <div className="blog-post__info">
              <h1 className="blog-post__title">{wisata.name}</h1>
              <p className="blog-post__text">{wisata.desc1}</p>
              <Link to={`/wisatakami/${wisata.id}`}>
                <a className="blog-post__cta">Baca Selengkapnya</a>
              </Link>
            </div>
          </div>
        ))}
      </div>
      <Footer />
    </div>
  );
};

export default WisataKu;
