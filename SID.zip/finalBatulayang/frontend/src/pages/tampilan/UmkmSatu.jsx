import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate, Link } from "react-router-dom";
import Navbar from "../../components/navbar/NavbarUser";
import "../../static/css/satu.css";
import Footer from "../../components/Footeri";

const UmkmSatu = () => {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState("");
  const [desc1, setDesc1] = useState("");
  const [desc2, setDesc2] = useState("");
  const [nowa, setNowa] = useState("");
  const [preview, setPreview] = useState("");
  const { id } = useParams();
  const [umkms, setUmkm] = useState([]);

  useEffect(() => {
    getUmkmById();
    getUmkm();
  }, []);

  const getUmkmById = async () => {
    const response = await axios.get(`http://localhost:5002/umkms/${id}`);
    setTitle(response.data.name);
    setFile(response.data.image);
    setPreview(response.data.url);
    setDesc1(response.data.desc1);
    setDesc2(response.data.desc2);
    setNowa(response.data.nowa);
  };
  const getUmkm = async () => {
    const response = await axios.get("http://localhost:5002/umkms");
    const totalUmkms = response.data.length;
    const latestUmkms = response.data.slice(totalUmkms - 3, totalUmkms);
    setUmkm(latestUmkms);
  };

  return (
    <div className="body">
      <Navbar />

      <div className="news-container">
        <div className="news-header">
          <h1>{title}</h1>
          <p className="author">{nowa}</p>
        </div>
        <div className="image-container">
          {preview ? <img src={preview} alt="Preview " /> : ""}
        </div>
        <div className="content">
          <p>{desc2}</p>
        </div>
      </div>
      <div className="juduls">
        <h1>Umkm lainnya</h1>
      </div>
      <div className="isian">
        <div className="card-container">
          {umkms.map((umkm) => (
            <div className="card" key={umkm.id}>
              <img src={umkm.url} alt="" />
              <h2>{umkm.name}</h2>
              <p>{umkm.desc1}</p>
              <a href={`/umkmkami/${umkm.id}`}>Baca Selengkapnya</a>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default UmkmSatu;
