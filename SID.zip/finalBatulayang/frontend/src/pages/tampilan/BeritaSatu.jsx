import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import Navbar from "../../components/navbar/NavbarUser";
import "../../static/css/satu.css";
import Footer from "../../components/Footeri";

const BeritaSatu = () => {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState("");
  const [desc1, setDesc1] = useState("");
  const [desc2, setDesc2] = useState("");
  const [penulis, setPenulis] = useState("");
  const [preview, setPreview] = useState("");
  const { id } = useParams();

  const [beritas, setBerita] = useState([]);

  useEffect(() => {
    getBeritaById();
    getBerita();
  }, []);

  const getBeritaById = async () => {
    const response = await axios.get(`http://localhost:5002/beritas/${id}`);
    setTitle(response.data.name);
    setFile(response.data.image);
    setPreview(response.data.url);
    setDesc1(response.data.desc1);
    setDesc2(response.data.desc2);
    setPenulis(response.data.penulis);
  };
  const getBerita = async () => {
    const response = await axios.get("http://localhost:5002/beritas");
    const totalBeritas = response.data.length;
    const latestBeritas = response.data.slice(totalBeritas - 3, totalBeritas);
    setBerita(latestBeritas);
  };

  return (
    <div className="body">
      <Navbar />
      <div className="news-container">
        <div className="news-header">
          <h1>{title}</h1>
          <p className="author">{penulis}</p>
        </div>
        <div className="image-container">
          {preview ? <img src={preview} alt="Preview " /> : ""}
        </div>
        <div className="content">
          <p>{desc2}</p>
        </div>
      </div>
      <div className="juduls">
        <h1>Berita lainnya</h1>
      </div>
      <div className="isian">
        <div className="card-container">
          {beritas.map((berita) => (
            <div className="card" key={berita.id}>
              <img src={berita.url} alt="" />
              <h2>{berita.name}</h2>
              <p>{berita.desc1}</p>
              <a href={`/beritakami/${berita.id}`}>Baca Selengkapnya</a>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default BeritaSatu;
