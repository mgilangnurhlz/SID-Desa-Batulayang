import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate, Link } from "react-router-dom";
import Navbar from "../../components/navbar/NavbarUser";
import "../../static/css/satu.css";
import Footer from "../../components/Footeri";

const WisataSatu = () => {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState("");
  const [desc1, setDesc1] = useState("");
  const [desc2, setDesc2] = useState("");
  const [alamat, setAlamat] = useState("");
  const [maps, setMaps] = useState("");
  const [nowa, setNowa] = useState("");
  const [preview, setPreview] = useState("");
  const { id } = useParams();

  const [wisatas, setWisata] = useState([]);

  useEffect(() => {
    getWisataById();
    getWisata();
  }, []);

  const getWisataById = async () => {
    const response = await axios.get(`http://localhost:5002/wisatas/${id}`);
    setTitle(response.data.name);
    setFile(response.data.image);
    setPreview(response.data.url);
    setDesc1(response.data.desc1);
    setDesc2(response.data.desc2);
    setAlamat(response.data.alamat);
    setMaps(response.data.maps);
    setNowa(response.data.nowa);
  };

  const getWisata = async () => {
    const response = await axios.get("http://localhost:5002/wisatas");
    const totalWisatas = response.data.length;
    const latestWisatas = response.data.slice(totalWisatas - 3, totalWisatas);
    setWisata(latestWisatas);
  };

  return (
    <div className="body">
      <Navbar />
      <div className="news-container">
        <div className="news-header">
          <h1>{title}</h1>
          <p className="author">{nowa}</p>
        </div>
        <div className="image-container">
          {preview ? <img src={preview} alt="Preview " /> : ""}
        </div>
        <div className="content">
          <p>{desc2}</p>
          <p>{alamat}</p>
          <a href={maps}>link</a>
        </div>
      </div>
      <div className="juduls">
        <h1>Wisata lainnya</h1>
      </div>
      <div className="isian">
        <div className="card-container">
          {wisatas.map((wisata) => (
            <div className="card" key={wisata.id}>
              <img src={wisata.url} alt="" />
              <h2>{wisata.name}</h2>
              <p>{wisata.desc1}</p>
              <a href={`/wisatakami/${wisata.id}`}>Baca Selengkapnya</a>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default WisataSatu;
