import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "../../static/css/kami.css";
import Navbar from "../../components/navbar/NavbarUser";
import Footer from "../../components/Footeri";

const BeritaList = () => {
  const [beritas, setBerita] = useState([]);

  useEffect(() => {
    getBerita();
  }, []);

  const getBerita = async () => {
    const response = await axios.get("http://localhost:5002/beritas");
    setBerita(response.data.reverse());
  };

  return (
    <div className="">
      <Navbar />
      <div className="kebawah">
        {beritas.map((berita) => (
          <div className="blog-post" key={berita.id}>
            <div className="blog-post__img">
              <img src={berita.url} alt="something" />
            </div>
            <div className="blog-post__info">
              <h1 className="blog-post__title">{berita.name}</h1>
              <p className="blog-post__text">{berita.desc1}</p>
              <Link to={`/beritakami/${berita.id}`}>
                <a className="blog-post__cta">Baca Selengkapnya</a>
              </Link>
            </div>
          </div>
        ))}
      </div>
      <Footer />
    </div>
  );
};

export default BeritaList;
