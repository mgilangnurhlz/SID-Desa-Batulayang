import React from "react";
import Navbar from "../components/Navbar";

const Layout = ({ children }) => {
  return (
    <React.Fragment>
      <Navbar />
      <div className="columns mt-6" style={{ minHeight: "100vh" }}>
        <div className="column has-background-light">
          <div>{children}</div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Layout;
