import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

//Login
import Login from "./components/Login";
import Dashboard from "./pages/Dashboard";

//User
import Users from "./pages/user/Users";
import AddUser from "./pages/user/AddUser";
import EditUser from "./pages/user/EditUser";

//Berita
import Beritas from "./pages/berita/Beritas";
import AddBerita from "./pages/berita/AddBerita";
import EditBerita from "./pages/berita/EditBerita";

//Wisata
import Wisatas from "./pages/wisata/Wisatas";
import AddWisata from "./pages/wisata/AddWisata";
import EditWisata from "./pages/wisata/EditWisata";

//Umkm
import Umkms from "./pages/umkm/Umkms";
import AddUmkm from "./pages/umkm/AddUmkm";
import EditUmkm from "./pages/umkm/EditUmkm";

//User Interface
import Index from "./pages/Index";
import BeritaKami from "./pages/tampilan/BeritaKami";
import BeritaSatu from "./pages/tampilan/BeritaSatu";
import UmkmKami from "./pages/tampilan/UmkmKami";
import UmkmSatu from "./pages/tampilan/UmkmSatu";
import WisataKami from "./pages/tampilan/WisataKami";
import WisataSatu from "./pages/tampilan/WisataSatu";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/umkmkami" element={<UmkmKami />} />
          <Route path="/umkmkami/:id" element={<UmkmSatu />} />
          <Route path="/beritakami" element={<BeritaKami />} />
          <Route path="/beritakami/:id" element={<BeritaSatu />} />
          <Route path="/wisatakami" element={<WisataKami />} />
          <Route path="/wisatakami/:id" element={<WisataSatu />} />

          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/users" element={<Users />} />
          <Route path="/users/add" element={<AddUser />} />
          <Route path="/users/edit/:id" element={<EditUser />} />

          <Route path="/beritas" element={<Beritas />} />
          <Route path="/beritas/add" element={<AddBerita />} />
          <Route path="/beritas/edit/:id" element={<EditBerita />} />

          <Route path="/wisatas" element={<Wisatas />} />
          <Route path="/wisatas/add" element={<AddWisata />} />
          <Route path="/wisatas/edit/:id" element={<EditWisata />} />

          <Route path="/umkms" element={<Umkms />} />
          <Route path="/umkms/add" element={<AddUmkm />} />
          <Route path="/umkms/edit/:id" element={<EditUmkm />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
